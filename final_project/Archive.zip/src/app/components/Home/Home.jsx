import React, { Component } from 'react';
import './Home.scss';

export class Home extends Component {
  render() {
    return <div className='page-content home-page'>Hello from home page</div>;
  }
}
