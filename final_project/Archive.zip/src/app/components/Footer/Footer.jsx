import React, { Component } from 'react';

export class Footer extends Component {
  render() {
    return (
      <footer className='page-footer'>
        <p>
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Ea dolore
          fugit, odio earum iste accusantium magnam similique repellat, non
          deserunt itaque odit. Nulla vitae aliquam iusto cumque mollitia fuga
          expedita.
        </p>
      </footer>
    );
  }
}
