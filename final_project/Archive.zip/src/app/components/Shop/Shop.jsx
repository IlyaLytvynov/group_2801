import React, { Component } from 'react';
import './Shop.scss';

export class Shop extends Component {
  render() {
    return <div className='page-content shop-page'>Hello from shop page</div>;
  }
}
